# Gilang Yudhistyra Dalimunthe — Resume Website (GitHub Pages)

This is a **static** resume website (HTML/CSS/JS) ready for **GitHub Pages** deployment.

## Deploy
1. Create a new GitHub repo (example: `resume`).
2. Upload everything in this folder to the repo (keep the same structure).
3. In GitHub: **Settings → Pages**
   - Source: **Deploy from a branch**
   - Branch: `main`
   - Folder: `/ (root)`

Your site will be available at:
`https://<your-username>.github.io/<repo-name>/`

## Customize
- Replace `assets/img/avatar.jpg` with your photo (same filename).
- The downloadable resume PDF is at:
  `assets/pdf/Gilang_Dalimunthe_Resume.pdf`
